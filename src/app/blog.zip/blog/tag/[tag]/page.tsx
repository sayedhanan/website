// File: app/blog/tag/[tag]/page.tsx
import { getAllTags, getPostsByTag, getAllCategories, POSTS_PER_PAGE } from '@/utils/blog-mdx';
import { CategoryNav } from '@/components/blog/CategoryNav';
import BlogPostsList from '@/components/blog/BlogPostsList';
import { notFound } from 'next/navigation';

interface TagPageProps {
  params: Promise<{ tag: string }>;
}

// Generate static params for all tags
export async function generateStaticParams() {
  const tags = await getAllTags();
  
  return tags.map((tag) => ({
    tag: encodeURIComponent(tag.toLowerCase()),
  }));
}

export default async function TagPage({ params }: TagPageProps) {
  const { tag } = await params;
  const decodedTag = decodeURIComponent(tag);
  
  const allTags = await getAllTags();
  const exactTag = allTags.find((t) => t.toLowerCase() === decodedTag.toLowerCase());
  
  if (!exactTag) notFound();

  // Load ALL posts for this tag at build time
  const tagPosts = await getPostsByTag(exactTag);
  const categories = await getAllCategories();

  return (
    <section className="section-wrapper section-spacing">
      <h1 className="text-3xl font-bold mb-6">Tag: #{exactTag}</h1>

      <CategoryNav categories={categories} />

      {tagPosts.length > 0 ? (
        <BlogPostsList 
          posts={tagPosts} 
          postsPerPage={POSTS_PER_PAGE}
        />
      ) : (
        <p className="mt-8">No posts found with this tag.</p>
      )}
    </section>
  );
}