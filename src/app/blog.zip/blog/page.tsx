import { getAllPosts, getAllCategories, POSTS_PER_PAGE } from '@/utils/blog-mdx';
import { CategoryNav } from '@/components/blog/CategoryNav';
import BlogPostsList from '@/components/blog/BlogPostsList';
import { notFound } from 'next/navigation';

type Props = {
  params: Promise<{ page: string }>;
};

export async function generateStaticParams() {
  const allPosts = await getAllPosts();
  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE);
  
  return Array.from({ length: totalPages - 1 }, (_, i) => ({
    page: (i + 2).toString(), // Start from page 2 since page 1 is handled by /blog
  }));
}

export async function generateMetadata({ params }: Props) {
  const { page } = await params;
  const pageNumber = parseInt(page, 10);
  
  return {
    title: `Blog - Page ${pageNumber}`,
    description: `Blog posts page ${pageNumber}`,
  };
}

export default async function BlogPageDynamic({ params }: Props) {
  const { page } = await params;
  const pageNumber = parseInt(page, 10);
  
  // Load ALL posts at build time
  const allPosts = await getAllPosts();
  const categories = await getAllCategories();
  
  // Validate page number
  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE);
  if (pageNumber < 2 || pageNumber > totalPages) {
    notFound();
  }

  return (
    <section className="section-wrapper section-spacing">
      <h1 className="text-3xl font-bold mb-6">Blog</h1>

      <CategoryNav categories={categories} />

      <BlogPostsList 
        posts={allPosts} 
        postsPerPage={POSTS_PER_PAGE}
        currentPage={pageNumber}
      />
    </section>
  );
}