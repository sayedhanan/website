// File: app/blog/category/[category]/page.tsx
import { getAllCategories, getPostsByCategory, POSTS_PER_PAGE } from '@/utils/blog-mdx';
import { CategoryNav } from '@/components/blog/CategoryNav';
import BlogPostsList from '@/components/blog/BlogPostsList';
import { notFound } from 'next/navigation';

interface CategoryPageProps {
  params: Promise<{ category: string }>;
}

// Generate static params for all categories
export async function generateStaticParams() {
  const categories = await getAllCategories();
  
  return categories.map((category) => ({
    category: encodeURIComponent(category.toLowerCase()),
  }));
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { category } = await params;
  const decodedCategory = decodeURIComponent(category);
  
  const allCategories = await getAllCategories();
  const exactCategory = allCategories.find(
    (cat) => cat.toLowerCase() === decodedCategory.toLowerCase()
  );
  
  if (!exactCategory) notFound();

  // Load ALL posts for this category at build time
  const categoryPosts = await getPostsByCategory(exactCategory);

  return (
    <section className="section-wrapper section-spacing">
      <h1 className="text-3xl font-bold mb-6">Category: {exactCategory}</h1>

      <CategoryNav categories={allCategories} />

      {categoryPosts.length > 0 ? (
        <BlogPostsList 
          posts={categoryPosts} 
          postsPerPage={POSTS_PER_PAGE}
        />
      ) : (
        <p className="mt-8">No posts found in this category.</p>
      )}
    </section>
  );
}