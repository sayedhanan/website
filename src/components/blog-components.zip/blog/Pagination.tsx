'use client'

import Link from 'next/link';
import { usePathname } from 'next/navigation';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  basePath?: string; // e.g., '/blog', '/blog/category/tech', '/blog/tag/javascript'
}

export default function Pagination({ 
  currentPage, 
  totalPages, 
  basePath = '/blog'
}: PaginationProps) {
  const pathname = usePathname();
  
  // Don't render if there's only one page or no pages
  if (totalPages <= 1) return null;

  // Function to generate the URL for a specific page
  const getPageUrl = (page: number) => {
    if (page === 1) {
      return basePath;
    }
    return `${basePath}/page/${page}`;
  };

  // Show at most 5 pages with ellipsis
  let pagesToShow: (number | string)[] = [];
  
  if (totalPages <= 5) {
    // If we have 5 or fewer pages, show all
    pagesToShow = Array.from({ length: totalPages }, (_, i) => i + 1);
  } else {
    // Always include first and last page
    if (currentPage <= 3) {
      // Near the start
      pagesToShow = [1, 2, 3, 4, '...', totalPages];
    } else if (currentPage >= totalPages - 2) {
      // Near the end
      pagesToShow = [1, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
    } else {
      // Somewhere in the middle
      pagesToShow = [1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages];
    }
  }

  return (
    <nav className="mt-8 flex justify-center space-x-2" role="navigation" aria-label="Pagination">
      {currentPage > 1 && (
        <Link 
          href={getPageUrl(currentPage - 1)}
          className="btn btn-outline"
          aria-label="Previous page"
          scroll={true}
        >
          Prev
        </Link>
      )}
      
      {pagesToShow.map((page, i) => (
        page === '...' ? (
          <span key={`ellipsis-${i}`} className="btn btn-disabled" aria-hidden="true">...</span>
        ) : (
          <Link
            key={page}
            href={getPageUrl(page as number)}
            className={`btn ${page === currentPage ? "btn-primary" : "btn-secondary"}`}
            aria-current={page === currentPage ? "page" : undefined}
            aria-label={`Go to page ${page}`}
            scroll={true}
          >
            {page}
          </Link>
        )
      ))}
      
      {currentPage < totalPages && (
        <Link 
          href={getPageUrl(currentPage + 1)}
          className="btn btn-outline"
          aria-label="Next page"
          scroll={true}
        >
          Next
        </Link>
      )}
    </nav>
  );
}