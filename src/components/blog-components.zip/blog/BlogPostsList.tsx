'use client'

import { useState, useMemo } from 'react';
import ArticleCard from '@/components/ui/article-card';
import Pagination from '@/components/blog/Pagination';
import type { Post } from '@/utils/blog-mdx';

interface BlogPostsListProps {
  posts: Post[];
  postsPerPage: number;
}

export default function BlogPostsList({ posts, postsPerPage }: BlogPostsListProps) {
  const [currentPage, setCurrentPage] = useState(1);

  // Calculate pagination
  const totalPages = Math.ceil(posts.length / postsPerPage);
  
  // Get posts for current page
  const currentPosts = useMemo(() => {
    const startIndex = (currentPage - 1) * postsPerPage;
    const endIndex = startIndex + postsPerPage;
    return posts.slice(startIndex, endIndex);
  }, [posts, currentPage, postsPerPage]);

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Reset to page 1 if posts change (useful when navigating between categories)
  useState(() => {
    setCurrentPage(1);
  });

  return (
    <>
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentPosts.map((post) => (
          <ArticleCard
            key={post.slug}
            href={`/blog/${post.slug}`}
            title={post.title}
            excerpt={post.abstract}
            date={post.date}
            readingTime={post.readingTime}
            categories={post.categories}
          />
        ))}
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
    </>
  );
}