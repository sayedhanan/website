'use client';

import React from 'react';
import { Highlight, themes, type Language } from 'prism-react-renderer';

interface CodeProps {
  children: string;
  className?: string;
}

export default function Code({ children, className = '' }: CodeProps) {
  // Extract the language (e.g. "language-js" → "js")
  const match = className.match(/language-(\w+)/);
  const lang = (match?.[1] ?? '') as Language;           // Prism-react-renderer v2 no longer exports defaultProps :contentReference[oaicite:4]{index=4}

  // Detect dark mode for theming (optional)
  const isDark =
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = isDark ? themes.vsDark : themes.github;

  return (
    <Highlight code={children.trim()} language={lang} theme={theme}>
      {({ className: inheritedClassName, style, tokens, getLineProps, getTokenProps }) => (
        <pre
          className={`${inheritedClassName} my-4 overflow-x-auto rounded-lg p-4`}
          style={style}
        >
          {tokens.map((line, i) => (
            <div key={i} {...getLineProps({ line, key: i })}>
              {line.map((token, key) => (
                <span key={key} {...getTokenProps({ token, key })} />
              ))}
            </div>
          ))}
        </pre>
      )}
    </Highlight>
  );
}
