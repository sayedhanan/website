export const navLinks = [
    { href: "/", label: "Home" },
    { href: "/blog", label: "Blog" },
    { href: "/courses", label: "Courses" },
    { href: "/about", label: "About" },
  ];
  