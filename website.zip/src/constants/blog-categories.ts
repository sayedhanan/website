export const blogCategories = [
    { label: 'All Posts', href: '/blog' },
    { label: 'JavaScript', href: '/blog/category/javascript' },
    { label: 'CSS', href: '/blog/category/css' },
    { label: 'React', href: '/blog/category/react' },
    // Add more categories as needed
  ];