import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Saye Hanan',
  description: 'A Next.js + MDX site with PrismJS',
};