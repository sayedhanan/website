// Required by @next/mdx in the App Router

import type { MDXComponents } from 'mdx/types';
import Code from "./src/components/Code"

const components: MDXComponents = {
    code: Code,
};
export default components;