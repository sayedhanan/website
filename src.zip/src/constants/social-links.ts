import { Github } from "lucide-react";

export const socialLinks = [
  {
    href: "https://github.com/your-profile",
    label: "GitHub",
    icon: Github,
  },
  // Future links can be added here
];
