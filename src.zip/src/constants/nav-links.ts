export const navLinks = [
    // { href: "/", label: "Home" },
    { href: "/blog", label: "Blog" },
    { href: "/notes", label: "Notes" },
    // { href: "/about", label: "About" },
    { href: "/newsletter", label: "Newsletter"},
    { href: "/contact", label: "Contact"},
  ];
  