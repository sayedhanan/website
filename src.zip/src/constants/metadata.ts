import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Sayed Hanan',
  description: 'A Next.js + MDX site with PrismJS',
};