// Required by @next/mdx in the App Router

import type { MDXComponents } from 'mdx/types';

const components: MDXComponents = {};
export default components;